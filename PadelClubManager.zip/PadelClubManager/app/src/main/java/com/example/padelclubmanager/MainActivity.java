package com.example.padelclubmanager;

import static com.google.firebase.database.DataSnapshot.*;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private Button login, signup;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            checkIfUserIsAdmin(currentUser.getUid());
        } else {
            setContentView(R.layout.activity_main);
        }
       /* if(currentUser == null){
            setContentView(R.layout.activity_main);
        } else {
            checkIfUserIsAdmin(currentUser.getUid());
        }*/


        login = (Button) findViewById(R.id.login);
        signup = (Button) findViewById(R.id.signup);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent logIntent = new Intent(MainActivity.this,Login.class);
                startActivity(logIntent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signIntent = new Intent(MainActivity.this,SignUp.class);
                startActivity(signIntent);
            }
        });
    }

    private void checkIfUserIsAdmin(String userId) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.getKey().isEmpty()) {
                    Boolean isAdmin = dataSnapshot.child("isAdmin").getValue(Boolean.class);
                    if (Boolean.TRUE.equals(isAdmin)) {
                        Toast.makeText(MainActivity.this, "Welcome, Admin!", Toast.LENGTH_SHORT).show();
                        // Navigate to admin activity
                        startActivity(new Intent(MainActivity.this, AdminActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this, "Welcome, User!", Toast.LENGTH_SHORT).show();
                        // Navigate to user activity
                        startActivity(new Intent(MainActivity.this, UserActivity.class));
                    }
                } else {
                    Toast.makeText(MainActivity.this, "User data not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });






        /*
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.getKey().isEmpty()) {
                    Boolean isAdmin = dataSnapshot.child("isAdmin").getValue(Boolean.class);
                    if (Boolean.TRUE.equals(isAdmin)) {
                        Toast.makeText(MainActivity.this, "Welcome, Admin!", Toast.LENGTH_SHORT).show();
                        // Navigate to admin activity
                        startActivity(new Intent(MainActivity.this, AdminActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this, "Welcome, User!", Toast.LENGTH_SHORT).show();
                        // Navigate to user activity
                        startActivity(new Intent(MainActivity.this, UserActivity.class));
                    }
                } else {
                    Toast.makeText(MainActivity.this, "User data not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });*/
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (mAuth.getCurrentUser() != null) {
            checkIfUserIsAdmin(mAuth.getCurrentUser().getUid());
        }
    }
}


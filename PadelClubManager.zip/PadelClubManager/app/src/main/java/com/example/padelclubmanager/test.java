package com.example.padelclubmanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class test extends AppCompatActivity {

    private EditText editTextFieldName;
    private Button buttonAddField;
    private ListView listViewFields;

    private DatabaseReference databaseFields;
    private ArrayList<String> fieldList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        editTextFieldName = findViewById(R.id.editTextFieldName);
        buttonAddField = findViewById(R.id.buttonAddField);
        listViewFields = findViewById(R.id.listViewFields);

        // Inizializza Firebase Database
        databaseFields = FirebaseDatabase.getInstance().getReference("fields");

        // Inizializza la lista e l'adapter
        fieldList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, fieldList);
        listViewFields.setAdapter(adapter);

        // Aggiungi campo al database
        buttonAddField.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addField();
            }
        });

        // Recupera e mostra i campi dal database
        databaseFields.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                fieldList.clear();
                for (DataSnapshot fieldSnapshot : snapshot.getChildren()) {
                    String fieldName = fieldSnapshot.getValue(String.class);
                    fieldList.add(fieldName);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Gestisci l'errore
            }
        });
    }

    private void addField() {
        String fieldName = editTextFieldName.getText().toString().trim();
        if (!fieldName.isEmpty()) {
            String id = databaseFields.push().getKey();
            databaseFields.child(id).setValue(fieldName);
            editTextFieldName.setText("");
        }
    }
}
